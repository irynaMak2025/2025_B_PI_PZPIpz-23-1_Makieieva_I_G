from django import forms
from client.models import Client


class ClientForm(forms.ModelForm):
    class Meta:
        model = Client
        fields = [
            "first_name",
            "last_name",
            "address",
            "passport",
            "gender",
            "email",
            "phone",
            "dob",
        ]
        labels = {
            "first_name": "Ім’я",
            "last_name": "Прізвище",
            "address": "Адреса",
            "passport": "Паспорт",
            "gender": "Стать",
            "email": "Email",
            "phone": "Телефон",
            "dob": "Дата народження",
        }
        widgets = {
            "dob": forms.DateInput(attrs={"type": "date"}),
        }

    def __init__(self, *args, **kwargs):
        super(ClientForm, self).__init__(*args, **kwargs)
        for name, field in self.fields.items():
            widget = field.widget
            if isinstance(widget, forms.Select):
                widget.attrs["class"] = "form-select"
            elif isinstance(widget, forms.Textarea):
                widget.attrs["class"] = "form-control"
                widget.attrs["rows"] = 4
            else:
                widget.attrs["class"] = "form-control"
