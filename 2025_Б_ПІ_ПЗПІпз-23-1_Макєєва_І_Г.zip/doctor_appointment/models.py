from django.db import models
from client.models import Client
from datetime import datetime, timedelta
from django.contrib.auth.models import User



class Doctor(models.Model):
    DoctorID = models.AutoField(primary_key=True)
    user = models.OneToOneField(User, on_delete=models.CASCADE)  # 🔑 зв'язок з auth.User
    name = models.CharField(max_length=100)
    specialty = models.CharField(max_length=100)
    start_work = models.DateField()

    def __str__(self):
        return self.name


class Schedule(models.Model):
    DAY_CHOICES = [
        (0, 'Monday'), (1, 'Tuesday'), (2, 'Wednesday'),
        (3, 'Thursday'), (4, 'Friday'), (5, 'Saturday'), (6, 'Sunday')
    ]

    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE, related_name="schedules")
    day_of_week = models.IntegerField(choices=DAY_CHOICES)
    start_time = models.TimeField()
    end_time = models.TimeField()

    def __str__(self):
        return f"{self.doctor.name} - {self.get_day_of_week_display()} ({self.start_time} - {self.end_time})"

    def generate_time_slots(self):
        """Генерує 30-хвилинні слоти між start_time і end_time"""
        slots = []
        current_time = datetime.combine(datetime.today(), self.start_time)
        end_datetime = datetime.combine(datetime.today(), self.end_time)

        while current_time < end_datetime:
            slots.append(current_time.time())
            current_time += timedelta(minutes=30)

        return slots


class Appointment(models.Model):
    patient = models.ForeignKey(Client, on_delete=models.CASCADE, related_name="appointments")
    schedule = models.ForeignKey(Schedule, on_delete=models.CASCADE, null=True, blank=True)
    appointment_time = models.DateTimeField()

    def __str__(self):
        return f"Appointment with {self.schedule.doctor.name} at {self.appointment_time}"



