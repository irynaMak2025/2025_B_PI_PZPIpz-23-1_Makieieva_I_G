from django.contrib import admin
from .models import Doctor, Schedule

@admin.register(Doctor)
class DoctorAdmin(admin.ModelAdmin):
    list_display = ("name", "specialty")
    search_fields = ("name", "specialty")

@admin.register(Schedule)
class ScheduleAdmin(admin.ModelAdmin):
    list_display = ("doctor", "day_of_week", "start_time", "end_time")
    list_filter = ("doctor", "day_of_week")

