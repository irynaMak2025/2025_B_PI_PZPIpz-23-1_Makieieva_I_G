from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from doctor_appointment.models import Doctor, Schedule, Appointment
from django.contrib.auth.decorators import login_required
from datetime import datetime, timedelta
from django.utils import timezone
from django.utils import timezone
from django.shortcuts import render
from client.models import Client

# Визначаємо назви днів тижня
WEEKDAYS = ["Понеділок", "Вівторок", "Середа", "Четвер", "П’ятниця", "Субота", "Неділя"]


def doctor_list(request):
    doctors = Doctor.objects.all()
    return render(request, "doctor_appointment/doctor_list.html", {"doctors": doctors})


def doctor_schedule(request, doctor_id):
    doctor = get_object_or_404(Doctor, id=doctor_id)
    schedule = Schedule.objects.filter(doctor=doctor)
    return render(
        request,
        "doctor_appointment/doctor_schedule.html",
        {"doctor": doctor, "schedule": schedule},
    )
    print("SCHEDULES FOUND:", schedules)


def about(request):
    return render(request, "doctor_appointment/about.html")

    # Отримуємо всі вже зайняті записи для цього лікаря


@login_required
def book_appointment(request, doctor_id):
    doctor = get_object_or_404(Doctor, pk=doctor_id)
    client = get_object_or_404(Client, user=request.user)
    schedules = Schedule.objects.filter(doctor=doctor)
    today = timezone.localdate()
    available_slots = {}
    booked_slots = {}

    # Отримуємо всі записи для цього лікаря
    booked_appointments = Appointment.objects.filter(schedule__doctor=doctor)

    for i in range(7):  # Розклад на 7 днів
        current_date = today + timedelta(days=i)
        weekday = current_date.weekday()
        work_schedule = schedules.filter(day_of_week=weekday).first()

        if work_schedule:
            slots = []
            booked = []
            start_time = datetime.combine(current_date, work_schedule.start_time)
            end_time = datetime.combine(current_date, work_schedule.end_time)

            while start_time < end_time:
                if booked_appointments.filter(appointment_time=start_time).exists():
                    booked.append(start_time.strftime("%Y-%m-%d %H:%M"))
                else:
                    slots.append(start_time.strftime("%Y-%m-%d %H:%M"))
                start_time += timedelta(minutes=30)

            date_label = f"{WEEKDAYS[weekday]} ({current_date.strftime('%d.%m.%Y')})"
            available_slots[date_label] = slots
            booked_slots[date_label] = booked

    if request.method == "POST":
        appointment_time_str = request.POST.get("appointment_time")
        if appointment_time_str:
            try:
                appointment_time = datetime.strptime(
                    appointment_time_str, "%Y-%m-%d %H:%M"
                )

                # Захист: вже хтось записався?
                if Appointment.objects.filter(
                    schedule__doctor=doctor, appointment_time=appointment_time
                ).exists():
                    messages.error(
                        request, "Цей час вже зайнятий. Будь ласка, оберіть інший."
                    )
                    return redirect("book_appointment", doctor_id=doctor.id)

                # Захист: користувач вже записаний на цей час?
                if Appointment.objects.filter(
                    patient=client, appointment_time=appointment_time
                ).exists():
                    messages.error(request, "Ви вже записані на цей час.")
                    return redirect("book_appointment", doctor_id=doctor.id)

                selected_schedule = schedules.filter(
                    day_of_week=appointment_time.weekday()
                ).first()

                Appointment.objects.create(
                    patient=client,
                    schedule=selected_schedule,
                    appointment_time=appointment_time,
                )

                messages.success(request, "Ви успішно записалися на прийом!")
                return redirect("appointment_success")

            except ValueError:
                messages.error(request, "Невірний формат дати. Спробуйте ще раз.")

    return render(
        request,
        "doctor_appointment/book_appointment.html",
        {
            "doctor": doctor,
            "available_slots": available_slots,
            "booked_slots": booked_slots.items(),
        },
    )


def appointment_success(request):
    return render(request, "doctor_appointment/appointment_success.html")
