from django.urls import path, include
from django.contrib.auth import views as auth_views
from clinic_info import views
from clinic_info.views import CustomLoginView


app_name = "clinic_info"

urlpatterns = [
    # Головна сторінка
    #  path('', views.home, name='home'),
    # Опитування
    # path("question/", views.index, name="index"),
    # path("question/<int:question_id>/", views.detail, name="detail"),
    # path("question/<int:question_id>/results/", views.results, name="results"),
    # path("question/<int:question_id>/vote/", views.vote, name="vote"),
    # Авторизація
    path("register/", views.register, name="register"),
    path("login/", CustomLoginView.as_view(), name="login"),
    path(
        "logout/",
        auth_views.LogoutView.as_view(template_name="users/logout.html"),
        name="logout",
    ),
    path(
        "reset_password/", auth_views.PasswordResetView.as_view(), name="password_reset"
    ),
    path(
        "reset_password_sent/",
        auth_views.PasswordResetDoneView.as_view(),
        name="password_reset_done",
    ),
    path(
        "reset/<uidb64>/<token>/",
        auth_views.PasswordResetConfirmView.as_view(),
        name="password_reset_confirm",
    ),
    path(
        "reset_password_complete/",
        auth_views.PasswordResetCompleteView.as_view(),
        name="password_reset_complete",
    ),
    # URLs для блогу
    path("blog/", views.post_list, name="blog-home"),
    # path('blog/', views.post_list, name='main_page'),
    path("post/new/", views.post_create, name="post_create"),
    path("post/<int:pk>/", views.post_detail, name="post-detail"),
    path("post/<int:pk>/update/", views.post_update, name="post-update"),
    path("post/<int:pk>/delete/", views.post_delete, name="post-delete"),
    path("accounts/redirect/", views.redirect_user, name="redirect_user"),
    path("client/dashboard/", views.client_dashboard, name="client_dashboard"),
    path("doctor/", include("doctor_panel.urls")),
    path("custom_ad/dashboard/", views.custom_ad_dashboard, name="custom_ad_dashboard"),
]
