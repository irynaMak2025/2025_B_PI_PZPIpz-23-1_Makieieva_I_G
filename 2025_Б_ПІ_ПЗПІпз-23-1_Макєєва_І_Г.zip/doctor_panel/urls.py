# doctor_panel/urls.py
from django.urls import path
from . import views
from .views import visit_pdf 

app_name = 'doctor_panel'  # ← ВАЖЛИВО: Це дозволяє використовувати namespace

urlpatterns = [
    path('dashboard/', views.doctor_dashboard, name='doctor_dashboard'),
    path('visit/<int:appointment_id>/', views.visit_detail, name='visit_detail'),
    path('visit/<int:appointment_id>/pdf/', visit_pdf, name='visit_pdf'),
]
