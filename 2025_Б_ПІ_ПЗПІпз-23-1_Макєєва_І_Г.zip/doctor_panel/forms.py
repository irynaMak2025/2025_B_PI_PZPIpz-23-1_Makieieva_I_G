# doctor_panel/forms.py
from django import forms
from doctor_panel.models import Prescription, Details


class PrescriptionForm(forms.ModelForm):
    class Meta:
        model = Prescription
        fields = ["Description"]
        labels = {
            "Description": "Призначення",
        }

    def __init__(self, *args, **kwargs):
        super(PrescriptionForm, self).__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs["class"] = "form-control"


class DetailsForm(forms.ModelForm):
    class Meta:
        model = Details
        fields = ["ServiceID", "Tooth"]
        labels = {
            "ServiceID": "Процедура",
            "Tooth": "Зуб",
        }

    def __init__(self, *args, **kwargs):
        super(DetailsForm, self).__init__(*args, **kwargs)
        for name, field in self.fields.items():
            widget = field.widget
            if isinstance(field.widget, forms.Select):
                widget.attrs["class"] = "form-select"
            else:
                widget.attrs["class"] = "form-control"
