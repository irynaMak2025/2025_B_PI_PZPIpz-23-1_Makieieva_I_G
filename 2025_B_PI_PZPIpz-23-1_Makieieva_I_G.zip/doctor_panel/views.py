from django.shortcuts import render, get_object_or_404, redirect
from django.db.models import Q
from django.contrib.auth.decorators import login_required, user_passes_test
from doctor_panel.models import Prescription, Details
from doctor_panel.models import Appointment, Doctor
from doctor_panel.forms import PrescriptionForm, DetailsForm
from datetime import date
from datetime import datetime
from django.utils.timezone import localtime
from django.http import HttpResponse
from django.template.loader import render_to_string
from weasyprint import HTML
from django.contrib import messages


def visit_pdf(request, appointment_id):
    # Отримуємо об'єкт прийому або 404, якщо не існує
    appointment = get_object_or_404(Appointment, pk=appointment_id)

    # Отримуємо призначення, якщо воно є
    try:
        prescription = Prescription.objects.filter(AppointmentID=appointment)
    except Prescription.DoesNotExist:
        raise Http404("Призначення не знайдено для цього візиту.")

    # Отримуємо деталі лікування (можна з фільтрацією)
    details = Details.objects.filter(
        AppointmentID=appointment
    ).first()  # якщо багато — буде перший

    # Генеруємо HTML із шаблону
    html_string = render_to_string(
        "doctor_panel/visit_pdf.html",
        {
            "appointment": appointment,
            "prescriptions": prescription,
            "details": details,
        },
    )

    # Генеруємо PDF
    pdf = HTML(string=html_string).write_pdf()

    # Повертаємо PDF як відповідь
    return HttpResponse(pdf, content_type="application/pdf")


# Create your views here.


def is_doctor(user):
    return user.is_authenticated and user.userprofile.role == "doctor"


@login_required
@user_passes_test(is_doctor)
def visit_detail(request, appointment_id):
    appointment = get_object_or_404(Appointment, pk=appointment_id)

    if request.method == "POST":
        prescription_form = PrescriptionForm(request.POST)
        details_form = DetailsForm(request.POST)

        if prescription_form.is_valid() and details_form.is_valid():
            # Призначення
            prescription = prescription_form.save(commit=False)
            prescription.AppointmentID = appointment  # 🟢 ОБОВʼЯЗКОВО
            prescription.save()

            # Процедура
            details = details_form.save(commit=False)
            details.AppointmentID = appointment  # 🟢 ТЕЖ ОБОВʼЯЗКОВО
            details.save()

            messages.success(request, "Дані збережено успішно ")
            return redirect("doctor_panel:visit_detail", appointment_id=appointment.pk)

    else:
        prescription = Prescription.objects.filter(AppointmentID=appointment).first()
        prescriptions_list = Prescription.objects.filter(AppointmentID=appointment)
        details = Details.objects.filter(AppointmentID=appointment).first()
        prescription_form = PrescriptionForm(instance=prescription)
        details_form = DetailsForm(instance=details)

    return render(
        request,
        "doctor_panel/visit_detail.html",
        {
            "appointment": appointment,
            "prescription_form": prescription_form,
            "details_form": details_form,
            "prescriptions_list": prescriptions_list,
        },
    )


@login_required
@user_passes_test(lambda u: u.userprofile.role == "doctor")
def doctor_dashboard(request):
    doctor = Doctor.objects.get(user=request.user)
    appointments = Appointment.objects.filter(schedule__doctor=doctor).select_related(
        "schedule", "patient"
    )

    # Фільтрація по пацієнту
    patient_id = request.GET.get("patient")
    if patient_id:
        appointments = appointments.filter(patient__id=patient_id)

    # Фільтрація по даті
    date_str = request.GET.get("date")
    if date_str:
        try:
            # Парсимо дату без часу
            date_obj = datetime.strptime(date_str, "%Y-%m-%d").date()
            appointments = appointments.filter(appointment_time__date=date_obj)
        except ValueError:
            pass  # Некоректний формат дати — ігноруємо

    # Список унікальних пацієнтів для дропдауну
    patients = (
        appointments.order_by("patient__last_name")
        .values("patient__id", "patient__first_name", "patient__last_name")
        .distinct()
    )

    # Формуємо об'єкти з id + ім'я
    patients = [
        type(
            "PatientObj",
            (),
            {
                "id": p["patient__id"],
                "first_name": p["patient__first_name"],
                "last_name": p["patient__last_name"],
            },
        )()
        for p in patients
    ]

    return render(
        request,
        "doctor_panel/doctor_dashboard.html",
        {
            "appointments": appointments,
            "patients": patients,
            "doctor": doctor,
        },
    )


@login_required
def patient_card(request, appointment_id):
    appointment = get_object_or_404(Appointment, id=appointment_id)
    prescriptions = Prescription.objects.filter(appointment=appointment)
    details = Details.objects.filter(appointment=appointment).select_related("service")

    return render(
        request,
        "doctor_appointment/patient_card.html",
        {
            "appointment": appointment,
            "prescriptions": prescriptions,
            "details": details,
        },
    )


@login_required
def add_treatment_info(request, appointment_id):
    appointment = get_object_or_404(Appointment, id=appointment_id)

    if request.method == "POST":
        diagnosis = request.POST.get("diagnosis")
        prescriptions = request.POST.getlist("prescriptions")
        service_ids = request.POST.getlist("service_ids")
        tooth_list = request.POST.getlist("tooths")

        if diagnosis:
            Prescription.objects.create(appointment=appointment, description=diagnosis)

        for service_id, tooth in zip(service_ids, tooth_list):
            Details.objects.create(
                appointment=appointment, service_id=service_id, tooth=tooth
            )

        messages.success(request, "Інформацію збережено")
        return redirect("doctor_dashboard")

    services = Service.objects.all()
    return render(
        request,
        "doctor_appointment/add_treatment_info.html",
        {"appointment": appointment, "services": services},
    )
