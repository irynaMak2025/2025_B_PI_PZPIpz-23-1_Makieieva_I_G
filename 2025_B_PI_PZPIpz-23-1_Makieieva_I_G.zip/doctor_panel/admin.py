from django.contrib import admin
from .models import Prescription, Service, Details

@admin.register(Prescription)
class PrescriptionAdmin(admin.ModelAdmin):
    list_display = ('PrescriptionID', 'AppointmentID', 'Description')
    search_fields = ('Description',)
    list_filter = ('AppointmentID',)

@admin.register(Service)
class ServiceAdmin(admin.ModelAdmin):
    list_display = ('ServiceID', 'ServiceName', 'ServiceCost')
    search_fields = ('ServiceName',)
    list_filter = ('ServiceCost',)

@admin.register(Details)
class DetailsAdmin(admin.ModelAdmin):
    list_display = ('DetailID', 'AppointmentID', 'ServiceID', 'Tooth')
    search_fields = ('Tooth',)
    list_filter = ('ServiceID',)

