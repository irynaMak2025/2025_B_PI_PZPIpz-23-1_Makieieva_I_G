from django.db import models
from doctor_appointment.models import Doctor, Appointment


# Create your models here.
class Prescription(models.Model):
    PrescriptionID = models.AutoField(primary_key=True)
    AppointmentID = models.ForeignKey(Appointment, on_delete=models.CASCADE)
    Description = models.TextField()


class Service(models.Model):
    ServiceID = models.AutoField(primary_key=True)
    ServiceName = models.CharField(max_length=100)
    ServiceCost = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return self.ServiceName


class Details(models.Model):
    DetailID = models.AutoField(primary_key=True)
    AppointmentID = models.ForeignKey(Appointment, on_delete=models.CASCADE)
    ServiceID = models.ForeignKey(Service, on_delete=models.CASCADE)
    Tooth = models.CharField(max_length=10)
