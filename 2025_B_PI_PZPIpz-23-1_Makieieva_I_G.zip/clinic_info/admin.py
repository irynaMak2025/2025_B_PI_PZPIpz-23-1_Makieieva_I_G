from django.contrib import admin
from django.contrib.auth.models import User  # Імпортуємо модель User
from django.contrib.auth.admin import UserAdmin
from clinic_info.models import Post, UserProfile

admin.site.unregister(User)  # Спочатку прибираємо стандартну реєстрацію
admin.site.register(User, UserAdmin)  # Додаємо з розширеним UserAdmin


@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display = ("title", "author", "date_posted")
    search_fields = ("title", "content")
    list_filter = ("date_posted",)
    date_hierarchy = "date_posted"
    ordering = ("-date_posted",)


@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ("user", "role")
    list_filter = ("role",)
    search_fields = ("user__username",)
