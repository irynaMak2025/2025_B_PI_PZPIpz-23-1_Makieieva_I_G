from django.contrib.auth.decorators import login_required, user_passes_test
from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse
from django.contrib import messages
from django.db.models import F
from clinic_info.models import Post, UserProfile
from clinic_info.forms import PostForm, UserRegistrationForm
from django.contrib.auth.views import LoginView

from clinic_info.forms import CustomLoginForm
from django.urls import reverse_lazy


# Головна сторінка (блог)
# def home(request):
#     return render(request, 'blog/main_page.html')
from django.core.exceptions import ObjectDoesNotExist


class CustomLoginView(LoginView):
    authentication_form = CustomLoginForm
    template_name = "users/login.html"

    def get_success_url(self):
        try:
            profile = self.request.user.userprofile
            if profile.role == "client":
                return reverse("client:client_dashboard")
            elif profile.role == "doctor":
                return reverse("doctor_panel:doctor_dashboard")
            elif profile.role == "admin":
                return reverse("clinic_info:custom_ad_dashboard")
        except ObjectDoesNotExist:
            # fallback if profile does not exist
            messages.error(
                self.request, "Ваш профіль не знайдено. Зверніться до адміністратора."
            )
            return reverse("clinic_info:login")


# Реєстрація
from clinic_info.models import UserProfile
from client.models import Client


def register(request):
    if request.method == "POST":
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            dob = form.cleaned_data.get("dob")
            # перевірка, чи профіль вже існує
            if not UserProfile.objects.filter(user=user).exists():
                UserProfile.objects.create(user=user, role="client")

            if not Client.objects.filter(user=user).exists():
                Client.objects.create(user=user, dob=dob)

            messages.success(request, "Реєстрація успішна! Тепер ви можете увійти.")
            return redirect("clinic_info:login")
    else:
        form = UserRegistrationForm()
    return render(request, "users/register.html", {"form": form})


def redirect_user(request):
    profile = UserProfile.objects.get(user=request.user)
    if profile.role == "doctor":
        return redirect("doctor_dashboard")
    elif profile.role == "client":
        return redirect("client_dashboard")
    elif profile.role == "admin":
        return redirect("custom_ad_dashboard")
    else:
        return redirect("clinic_info:login")


def is_client(user):
    return user.is_authenticated and user.userprofile.role == "client"


def is_doctor(user):
    return user.is_authenticated and user.userprofile.role == "doctor"


def is_admin(user):
    return user.is_authenticated and user.userprofile.role == "admin"


@login_required
def client_dashboard(request):
    return render(request, "client/client_dashboard.html")


@login_required
@user_passes_test(lambda u: u.userprofile.role == "doctor")
def doctor_dashboard(request):
    return render(request, "doctor_panel/doctor_dashboard.html")


@login_required
@user_passes_test(lambda u: u.userprofile.role == "admin")
def custom_ad_dashboard(request):
    return render(request, "users/custom_ad_dashboard.html")


# Блог
def post_list(request):
    posts = Post.objects.all().order_by("-date_posted")
    return render(request, "blog/main_page.html", {"posts": posts})


def post_detail(request, pk):
    post = get_object_or_404(Post, pk=pk)
    return render(request, "blog/post_detail.html", {"post": post})


@login_required
@user_passes_test(lambda u: is_doctor(u) or is_admin(u))
def post_create(request):
    if request.method == "POST":
        form = PostForm(request.POST)
        if form.is_valid():
            post = form.save(commit=False)
            post.author = request.user
            post.save()
            return redirect("clinic_info:post-detail", pk=post.pk)
    else:
        form = PostForm()
    return render(request, "blog/post_form.html", {"form": form})


@login_required
@user_passes_test(lambda u: is_doctor(u) or is_admin(u))
def post_update(request, pk):
    post = get_object_or_404(Post, pk=pk)

    if request.method == "POST":
        form = PostForm(request.POST, instance=post)
        if form.is_valid():
            form.save()
            return redirect("clinic_info:post-detail", pk=post.pk)
    else:
        form = PostForm(instance=post)
    return render(request, "blog/post_form.html", {"form": form})


@login_required
@user_passes_test(lambda u: is_doctor(u) or is_admin(u))
def post_delete(request, pk):
    post = get_object_or_404(Post, pk=pk)

    if request.method == "POST":
        post.delete()
        return redirect("clinic_info:blog-home")
    return render(request, "blog/post_confirm_delete.html", {"post": post})
