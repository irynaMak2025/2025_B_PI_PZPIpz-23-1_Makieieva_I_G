import shutil
import os

source_dir = r"E:\beetroot3_django_with_bootstrap_and_forms"
target_dir = os.path.expanduser(r"~/Desktop/Essay/Диплом_Макєєва І.Г")
output_path = os.path.join(target_dir, "clinic_project")

shutil.make_archive(output_path, 'zip', source_dir)

print(f" Архів створено: {output_path}.zip")

