from locust import HttpUser, task, between

class WebsiteUser(HttpUser):
    wait_time = between(1, 3)  # пауза між запитами

    @task
    def load_homepage(self):
        self.client.get("/")  # тестує головну сторінку

    @task
    def view_profile(self):
        self.client.get("/client/profile/")  #  сторінка профілю
