from django.contrib import admin
from client.models import Client


@admin.register(Client)
class ClientAdmin(admin.ModelAdmin):
    list_display = ['id', 'user']  # відображати в списку
    search_fields = ['user__username']  # дозволити пошук за ім’ям користувача
