from django.urls import path
from client import views


app_name = "client"

urlpatterns = [
    path("profile/", views.client_profile, name="client_profile"),
    path("dashboard/", views.client_dashboard, name="client_dashboard"),
    path(
        "cancel_appointment/<int:appointment_id>/",
        views.cancel_appointment,
        name="cancel_appointment",
    ),
]
