from django.shortcuts import render, redirect
from django.utils import timezone
from django.contrib.auth.decorators import login_required
from client.forms import ClientForm
from client.models import Client
from doctor_appointment.models import Appointment, Doctor
from doctor_panel.models import Prescription, Details, Service
from django.shortcuts import get_object_or_404
from django.shortcuts import redirect, get_object_or_404
from django.contrib import messages


@login_required
def client_profile(request):

    client = get_object_or_404(Client, user=request.user)

    if request.method == "POST":
        form = ClientForm(request.POST, instance=client)
        if form.is_valid():
            form.save()

            return redirect("client:client_profile")
    else:
        form = ClientForm(instance=client)

    return render(request, "client/profile.html", {"form": form})


@login_required
def client_dashboard(request):
    client = Client.objects.get(user=request.user)

    appointments = Appointment.objects.filter(patient=client).order_by(
        "-appointment_time"
    )

    doctor_id = request.GET.get("doctor")
    date = request.GET.get("date")

    print(doctor_id)
    print(date)

    if doctor_id:
        appointments = appointments.filter(schedule__doctor__DoctorID=doctor_id)
    if date:
        appointments = appointments.filter(appointment_time=date)

    doctors = Doctor.objects.all()

    return render(
        request,
        "client/client_dashboard.html",
        {
            "appointments": appointments,
            "doctors": doctors,
            "now": timezone.now(),
        },
    )


@login_required
def cancel_appointment(request, appointment_id):
    appointment = get_object_or_404(
        Appointment, pk=appointment_id, patient__user=request.user
    )

    if appointment.appointment_time > timezone.now():
        appointment.delete()
        messages.success(request, "Запис успішно скасовано.")
    else:
        messages.error(request, "Не можна скасувати минулий запис.")

    return redirect("client:client_dashboard")
